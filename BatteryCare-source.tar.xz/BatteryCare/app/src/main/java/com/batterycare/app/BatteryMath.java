package com.batterycare.app;

/** Pure calculations. Percentages are manual observations, never fabricated estimates. */
public final class BatteryMath {
    private BatteryMath() {}
    public static int suggestedInterval(String category, String kind, String mode) {
        if ("No battery".equals(kind) || "Stored without cells".equals(mode)) return 0;
        if ("Disposable AA/AAA".equals(kind)) return 180;
        if ("Sleeping".equals(mode)) {
            if ("Windows handheld".equals(category)) return 1;
            if ("AYN Thor".equals(category)) return 1;
            return 3;
        }
        if ("Hibernate".equals(mode)) return 14;
        if ("Controller".equals(category)) return 90;
        if ("Retro handheld".equals(category)) return 45;
        return 30;
    }
    /** When changing an existing sleep/hibernate preset to powered-off storage,
     * expand only known factory defaults. Never silently overwrite custom intervals. */
    public static int poweredOffInterval(String name,String category,String oldMode,int oldDays) {
        if (oldDays<1 || !("Android handheld".equals(category) || "Windows handheld".equals(category) || "Retro handheld".equals(category))) return oldDays;
        if ("AYN Thor".equals(name) && "Android handheld".equals(category) &&
                "Sleeping".equals(oldMode) && oldDays==1) return 7;
        if ("Windows handheld".equals(category) && "Sleeping".equals(oldMode) && oldDays==1) return 30;
        if ("Hibernate".equals(oldMode) && oldDays==14) return 30;
        if ("Android handheld".equals(category) && "Sleeping".equals(oldMode) && oldDays==3) return 30;
        return oldDays;
    }
    public static int suggestedInterval(String name,String category,String kind,String mode) {
        if ("AYN Thor".equalsIgnoreCase(name==null?"":name.trim()) &&
                "Android handheld".equals(category) && "Sleeping".equals(mode) &&
                !"No battery".equals(kind)) return 1;
        return suggestedInterval(category,kind,mode);
    }
    public static double drainPerDay(int oldLevel, int newLevel, long oldTime, long newTime) {
        if (oldLevel < 0 || oldLevel > 100 || newLevel < 0 || newLevel > 100 ||
            oldTime <= 0 || newTime <= oldTime || newLevel >= oldLevel) return Double.NaN;
        double days = (newTime - oldTime) / 86400000d;
        if (days < 0.20d) return Double.NaN;
        return (oldLevel - newLevel) / days;
    }
    /** Conservative suggestion, shortened only; prevents learning spurious optimistic intervals. */
    public static int drainBasedSuggestion(int currentLevel, double drainPerDay, int chosenInterval) {
        if (currentLevel < 0 || currentLevel > 100 || !Double.isFinite(drainPerDay) ||
            drainPerDay <= 0 || chosenInterval < 1) return chosenInterval;
        // Aim for a check before reaching 25%, but don't make it less than a day.
        int days = (int)Math.floor(Math.max(1, (currentLevel - 25) / drainPerDay * 0.75));
        return Math.max(1, Math.min(chosenInterval, days));
    }
    /** Calendar-day recurrence retains the user's local clock time across DST changes. */
    public static long nextCheckAt(long fromMillis,int days,java.time.ZoneId zone) {
        if(days<1||days>365)throw new IllegalArgumentException("Days must be 1–365");
        return java.time.Instant.ofEpochMilli(fromMillis).atZone(zone).plusDays(days).toInstant().toEpochMilli();
    }
    public static long nextCheckAt(long fromMillis,int days) {
        return nextCheckAt(fromMillis,days,java.time.ZoneId.systemDefault());
    }
    public static int clampLevel(int level) { return Math.max(-1, Math.min(100,level)); }
}
