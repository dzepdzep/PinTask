package com.batterycare.app;

import android.content.*;
import android.os.Handler;
import android.os.Looper;

/** Direct PendingIntent action receiver; never starts an Activity from the background. */
public final class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent intent) {
        if(intent==null)return;
        if(Reminders.ACTION_TEST.equals(intent.getAction())){Reminders.showTest(c);return;}
        long id=intent.getLongExtra(Reminders.EXTRA_ID,-1);
        if(id<=0)return;
        String action=intent.getAction();
        if(Reminders.ACTION_DUE.equals(action)){
            Reminders.deliverDue(c,"alarm");
        }else if(Reminders.ACTION_DONE.equals(action)||Reminders.ACTION_WIDGET_DONE.equals(action)) {
            AlarmSoundService.stopFor(c,id);
            DeviceStore.Device after;
            try(DeviceStore db=new DeviceStore(c)){after=db.complete(id,-1);}
            Reminders.cancelScheduled(c,id);Reminders.cancel(c,id);
            Reminders.schedule(c,after);
            BatteryWidget.updateAll(c);
            if(after!=null){EventLog.note(c,"checked",id);Reminders.showUndo(c,id,after.name);}
        }else if(Reminders.ACTION_UNDO.equals(action)) {
            DeviceStore.Device previous;
            try(DeviceStore db=new DeviceStore(c)){previous=db.undo(id);}
            if(previous!=null){
                Reminders.cancelScheduled(c,id);
                Reminders.cancelUndo(c,id);
                if(previous.remindedAt>0)Reminders.showDevice(c,previous,false);
                else Reminders.schedule(c,previous);
                BatteryWidget.updateAll(c);
            }
        }else if(Reminders.ACTION_STOP.equals(action)){
            AlarmSoundService.stopFor(c,id);
        }else if(Reminders.ACTION_DISMISS.equals(action)){
            // Android 14 may allow dismissing ongoing cards; restore without replaying sound.
            PendingResult async=goAsync();
            new Handler(Looper.getMainLooper()).postDelayed(()->{
                try(DeviceStore db=new DeviceStore(c)){
                    DeviceStore.Device d=db.get(id);
                    if(d!=null&&d.enabled&&d.remindedAt>0)Reminders.showDevice(c,d,false);
                }catch(RuntimeException failure){android.util.Log.w("BatteryCare","Restore failed",failure);}
                finally{async.finish();}
            },900L);
        }
    }
}
