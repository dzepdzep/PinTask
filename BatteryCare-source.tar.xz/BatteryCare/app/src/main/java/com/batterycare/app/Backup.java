package com.batterycare.app;

import android.app.Activity;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

/** Portable JSON backup of devices and check history; no cloud, tracking, or account. */
final class Backup {
    private Backup() {}
    static void exportPicker(Activity activity,int request){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType("application/json").putExtra(Intent.EXTRA_TITLE,"BatteryCare-backup.json");
        activity.startActivityForResult(i,request);
    }
    static void importPicker(Activity activity,int request){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
        activity.startActivityForResult(i,request);
    }
    static void write(Context c,Uri uri)throws Exception{
        JSONObject root=new JSONObject();root.put("format",1);root.put("app","BatteryCare");
        try(DeviceStore store=new DeviceStore(c)){
            SQLiteDatabase db=store.getReadableDatabase();
            root.put("devices",rows(db,"devices"));root.put("checks",rows(db,"checks"));
        }
        try(OutputStream out=c.getContentResolver().openOutputStream(uri,"wt")){
            if(out==null)throw new IOException("Unable to write selected file");
            out.write(root.toString(2).getBytes(StandardCharsets.UTF_8));
        }
    }
    private static JSONArray rows(SQLiteDatabase db,String table)throws JSONException{
        JSONArray result=new JSONArray();
        try(Cursor cursor=db.rawQuery("SELECT * FROM "+table,null)){
            while(cursor.moveToNext()){
                JSONObject obj=new JSONObject();
                for(int j=0;j<cursor.getColumnCount();j++){
                    String name=cursor.getColumnName(j);
                    if(cursor.isNull(j))obj.put(name,JSONObject.NULL);
                    else if(cursor.getType(j)==Cursor.FIELD_TYPE_INTEGER)obj.put(name,cursor.getLong(j));
                    else if(cursor.getType(j)==Cursor.FIELD_TYPE_FLOAT)obj.put(name,cursor.getDouble(j));
                    else obj.put(name,cursor.getString(j));
                }
                result.put(obj);
            }
        }return result;
    }
    static void read(Context c,Uri uri)throws Exception{
        byte[] bytes;
        try(InputStream in=c.getContentResolver().openInputStream(uri)){
            if(in==null)throw new IOException("Unable to open backup");
            ByteArrayOutputStream buf=new ByteArrayOutputStream();byte[] chunk=new byte[8192];int count;
            while((count=in.read(chunk))!=-1){
                if(buf.size()+count>4_000_000)throw new IOException("Backup exceeds 4 MB limit");
                buf.write(chunk,0,count);
            }bytes=buf.toByteArray();
        }
        JSONObject root=new JSONObject(new String(bytes,StandardCharsets.UTF_8));
        if(root.optInt("format",-1)!=1||!"BatteryCare".equals(root.optString("app")))
            throw new IOException("Unsupported backup type or version");
        JSONArray devices=root.getJSONArray("devices"),checks=root.getJSONArray("checks");
        if(devices.length()>500||checks.length()>10000)throw new IOException("Backup record limit exceeded");
        // Preflight validation happens before altering existing records.
        for(int i=0;i<devices.length();i++){
            JSONObject x=devices.getJSONObject(i);
            if(x.getLong("_id")<=0||x.getString("name").trim().isEmpty()||
                x.getString("name").length()>200||x.getInt("interval_days")<0||x.getInt("interval_days")>365||
                x.getInt("level") < -1||x.getInt("level")>100)
                throw new IOException("Invalid device at row "+(i+1));
        }
        for(int i=0;i<checks.length();i++){
            JSONObject x=checks.getJSONObject(i);
            if(x.getLong("device_id")<=0||x.getLong("checked_at")<=0||
                x.getInt("level") < -1 || x.getInt("level")>100)
                throw new IOException("Invalid check at row "+(i+1));
        }
        try(DeviceStore store=new DeviceStore(c)){
            for(DeviceStore.Device d:store.all()){
                Reminders.cancelScheduled(c,d.id);Reminders.cancel(c,d.id);
            }
            SQLiteDatabase db=store.getWritableDatabase();db.beginTransaction();
            try{
                db.delete("checks",null,null);db.delete("devices",null,null);
                for(int i=0;i<devices.length();i++){
                    JSONObject x=devices.getJSONObject(i);
                    db.insertOrThrow("devices",null,values(x,new String[]{"_id","name","category","kind","mode","interval_days","next_at","last_at","level","level_at","early_hours","reminded_at","snooze_until","enabled","notes"}));
                }
                for(int i=0;i<checks.length();i++){
                    JSONObject x=checks.getJSONObject(i);
                    db.insertOrThrow("checks",null,values(x,new String[]{"_id","device_id","checked_at","level","mode","prev_next_at","prev_last_at","prev_level","prev_level_at","prev_reminded_at","prev_snooze_until"}));
                }
                db.setTransactionSuccessful();
            }finally{db.endTransaction();}
        }catch(Exception failure){Reminders.rescheduleAll(c);throw failure;}
        Reminders.rescheduleAll(c);
    }
    private static ContentValues values(JSONObject obj,String[] keys)throws JSONException{
        ContentValues c=new ContentValues();
        for(String key:keys){
            if(!obj.has(key)||obj.isNull(key))continue;
            Object value=obj.get(key);
            if(value instanceof Integer||value instanceof Long)c.put(key,((Number)value).longValue());
            else if(value instanceof Number)c.put(key,((Number)value).doubleValue());
            else c.put(key,value.toString());
        }return c;
    }
}
