package com.batterycare.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import java.text.DateFormat;
import java.util.*;

/** Mirrors PinTask concepts: exact-when-authorized + fallback, claimed notifications, status icon. */
public final class Reminders {
    static final String ACTION_DUE="com.batterycare.app.DUE";
    static final String ACTION_DONE="com.batterycare.app.DONE";
    static final String ACTION_UNDO="com.batterycare.app.UNDO";
    static final String ACTION_STOP="com.batterycare.app.STOP";
    static final String ACTION_DISMISS="com.batterycare.app.DISMISS";
    static final String ACTION_WIDGET_DONE="com.batterycare.app.WIDGET_DONE";
    static final String EXTRA_ID="device_id";
    static final String CHANNEL_HIGH="battery_care_due_v1";
    static final String CHANNEL_QUIET="battery_care_quiet_v1";
    static final String CHANNEL_SILENT="battery_care_items_v1";
    static final String CHANNEL_STATUS="battery_care_status_v1";
    static final int STATUS_ID=998877;
    private Reminders() {}
    static void ensureChannels(Context c) {
        NotificationManager n=c.getSystemService(NotificationManager.class);if(n==null)return;
        AudioAttributes audio=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build();
        NotificationChannel high=new NotificationChannel(CHANNEL_HIGH,"Battery check alarms",NotificationManager.IMPORTANCE_HIGH);
        high.enableVibration(true);high.setVibrationPattern(new long[]{0,300,180,400});
        high.setSound(Settings.System.DEFAULT_ALARM_ALERT_URI,audio);n.createNotificationChannel(high);
        NotificationChannel quiet=new NotificationChannel(CHANNEL_QUIET,"Battery alarms without pop-ups",NotificationManager.IMPORTANCE_DEFAULT);
        quiet.enableVibration(true);quiet.setSound(Settings.System.DEFAULT_ALARM_ALERT_URI,audio);n.createNotificationChannel(quiet);
        NotificationChannel silent=new NotificationChannel(CHANNEL_SILENT,"Battery checklist",NotificationManager.IMPORTANCE_LOW);
        silent.setSound(null,null);silent.enableVibration(false);n.createNotificationChannel(silent);
        NotificationChannel status=new NotificationChannel(CHANNEL_STATUS,"Due-check status icon",NotificationManager.IMPORTANCE_DEFAULT);
        status.setSound(null,null);status.enableVibration(false);n.createNotificationChannel(status);
    }
    static String dueChannel(Context c){return Preferences.enabled(c,Preferences.POPUP)?CHANNEL_HIGH:CHANNEL_QUIET;}
    static boolean canNotify(Context c) {
        NotificationManager n=c.getSystemService(NotificationManager.class);
        return n!=null&&n.areNotificationsEnabled()&&
          (Build.VERSION.SDK_INT<33||c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED);
    }
    static boolean canDeliver(Context c) {
        if(!canNotify(c))return false;
        ensureChannels(c);NotificationManager n=c.getSystemService(NotificationManager.class);
        NotificationChannel channel=n.getNotificationChannel(dueChannel(c));
        return channel!=null&&channel.getImportance()!=NotificationManager.IMPORTANCE_NONE;
    }
    static boolean canExact(Context c) {
        AlarmManager a=c.getSystemService(AlarmManager.class);
        return a!=null&&(Build.VERSION.SDK_INT<31||a.canScheduleExactAlarms());
    }
    static PendingIntent intent(Context c,String action,long id,int flags) {
        Intent i=new Intent(c,ReminderReceiver.class).setAction(action)
            .setData(Uri.parse("batterycare://"+action+"/"+id)).putExtra(EXTRA_ID,id);
        return PendingIntent.getBroadcast(c,(int)(id%Integer.MAX_VALUE),i,flags|PendingIntent.FLAG_IMMUTABLE);
    }
    static PendingIntent open(Context c,long id) {
        Intent i=new Intent(c,MainActivity.class).putExtra(EXTRA_ID,id)
            .setAction(Intent.ACTION_VIEW).setData(Uri.parse("batterycare://open/"+id))
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c,(int)(id%Integer.MAX_VALUE),i,
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    static int notificationId(long id){return (int)(id%1_000_000)+1000;}
    static String when(long at){return DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.SHORT).format(new Date(at));}
    static void showDevice(Context c,DeviceStore.Device d,boolean alarmArrival) {
        if(d==null||!d.enabled||!canNotify(c))return;
        ensureChannels(c);
        NotificationManager n=c.getSystemService(NotificationManager.class);
        if(n==null)return;
        String channel=alarmArrival?dueChannel(c):CHANNEL_SILENT;
        PendingIntent done=intent(c,ACTION_DONE,d.id,PendingIntent.FLAG_UPDATE_CURRENT);
        Intent snooze=new Intent(c,SnoozeActivity.class).setData(Uri.parse("batterycare://snooze/"+d.id)).putExtra(EXTRA_ID,d.id);
        PendingIntent snoozeP=PendingIntent.getActivity(c,(int)d.id,snooze,
          PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        String details="Check battery / swelling · "+(d.level<0?"Level unknown":("Last noted "+d.level+"%"));
        Notification.Builder builder=new Notification.Builder(c,channel)
            .setSmallIcon(R.drawable.ic_battery)
            .setContentTitle("Battery check · "+d.name).setContentText(details)
            .setSubText("Due "+when(d.nextAt)).setContentIntent(open(c,d.id))
            .setDeleteIntent(intent(c,ACTION_DISMISS,d.id,PendingIntent.FLAG_UPDATE_CURRENT))
            .setCategory(Notification.CATEGORY_REMINDER)
            .setOngoing(true).setAutoCancel(false).setOnlyAlertOnce(true)
            .setLocalOnly(!Preferences.enabled(c,Preferences.WATCH))
            .addAction(new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(c,R.drawable.ic_battery),"Checked",done).build())
            .addAction(new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(c,R.drawable.ic_battery),"Snooze",snoozeP).build())
            .setStyle(new Notification.BigTextStyle().bigText(details+". When checked, tap Checked or open the app to record the percentage."));
        if(alarmArrival && Preferences.enabled(c,Preferences.SOUND))
            builder.addAction(new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(c,R.drawable.ic_battery),
                "Stop sound",intent(c,ACTION_STOP,d.id,PendingIntent.FLAG_UPDATE_CURRENT)).build());
        n.notify("battery-device",notificationId(d.id),builder.build());
        refreshStatus(c);
    }
    static void cancel(Context c,long id) {
        NotificationManager n=c.getSystemService(NotificationManager.class);
        if(n!=null)n.cancel("battery-device",notificationId(id));
        refreshStatus(c);
        BatteryWidget.updateAll(c);
    }
    static void showUndo(Context c,long id,String name) {
        if(!canNotify(c))return;
        Notification n=new Notification.Builder(c,CHANNEL_SILENT)
            .setSmallIcon(R.drawable.ic_battery)
            .setContentTitle("Checked · "+name).setContentText("Undo available for 10 seconds")
            .setTimeoutAfter(10_000L).setOnlyAlertOnce(true)
            .addAction(new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(c,R.drawable.ic_battery),
                "Undo",intent(c,ACTION_UNDO,id,PendingIntent.FLAG_UPDATE_CURRENT)).build())
            .build();
        c.getSystemService(NotificationManager.class).notify("battery-undo",notificationId(id),n);
    }
    static void cancelUndo(Context c,long id){
        NotificationManager n=c.getSystemService(NotificationManager.class);
        if(n!=null)n.cancel("battery-undo",notificationId(id));
    }
    static void refreshStatus(Context c) {
        NotificationManager n=c.getSystemService(NotificationManager.class);if(n==null)return;
        if(!Preferences.enabled(c,Preferences.STATUS)||!canNotify(c)) {n.cancel(STATUS_ID);return;}
        ensureChannels(c);
        List<DeviceStore.Device> all;
        try(DeviceStore db=new DeviceStore(c)){all=db.all();}
        int count=0;DeviceStore.Device first=null;
        for(DeviceStore.Device d:all)if(d.enabled&&d.remindedAt>0){count++;if(first==null)first=d;}
        if(count==0){n.cancel(STATUS_ID);return;}
        Notification notification=new Notification.Builder(c,CHANNEL_STATUS).setSmallIcon(R.drawable.ic_battery)
            .setContentTitle(count==1?"1 battery check due":count+" battery checks due")
            .setContentText(count==1?first.name:"Tap to review your devices")
            .setContentIntent(open(c,first.id)).setShowWhen(false)
            .setOngoing(true).setOnlyAlertOnce(true).build();
        n.notify(STATUS_ID,notification);
    }
    static void sync(Context c) {
        if(!canNotify(c))return;
        try(DeviceStore db=new DeviceStore(c)) {
            for(DeviceStore.Device d:db.all())if(d.enabled&&d.remindedAt>0)showDevice(c,d,false);
        }
        refreshStatus(c);BatteryWidget.updateAll(c);
    }
    static void schedule(Context c,DeviceStore.Device d) {
        if(d==null||!d.enabled||d.days<=0||d.remindedAt>0)return;
        RecoveryJob.ensure(c);
        AlarmManager alarms=c.getSystemService(AlarmManager.class);if(alarms==null)return;
        long time=d.notificationAt();
        if(time<=System.currentTimeMillis()){
            deliver(c,d.id,"overdue");return;
        }
        PendingIntent pi=intent(c,ACTION_DUE,d.id,PendingIntent.FLAG_UPDATE_CURRENT);
        if(canExact(c)) {
            try {
                if(Preferences.enabled(c,Preferences.ALARM_CLOCK)) {
                    alarms.setAlarmClock(new AlarmManager.AlarmClockInfo(time,open(c,d.id)),pi);
                    EventLog.note(c,"scheduled_alarm_clock",d.id);
                }else {
                    alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pi);
                    EventLog.note(c,"scheduled_exact",d.id);
                }
                return;
            }catch(SecurityException ignored){/* permission changed; use fallback */}
        }
        alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pi);
        EventLog.note(c,"scheduled_inexact",d.id);
    }
    static void cancelScheduled(Context c,long id) {
        AlarmManager m=c.getSystemService(AlarmManager.class);if(m==null)return;
        PendingIntent pi=intent(c,ACTION_DUE,id,PendingIntent.FLAG_NO_CREATE);
        if(pi!=null){m.cancel(pi);pi.cancel();}
    }
    static void rescheduleAll(Context c) {
        RecoveryJob.ensure(c);
        try(DeviceStore db=new DeviceStore(c)){
            for(DeviceStore.Device d:db.all())if(d.enabled){schedule(c,d);}
        }
        refreshStatus(c);BatteryWidget.updateAll(c);
    }
    static void deliverDue(Context c,String origin) {
        try(DeviceStore db=new DeviceStore(c)) {
            for(DeviceStore.Device d:db.all())if(d.enabled&&d.remindedAt==0&&d.notificationAt()<=System.currentTimeMillis())
                deliver(c,d.id,origin);
        }
    }
    static void deliver(Context c,long id,String origin) {
        if(!canDeliver(c)){
            EventLog.note(c,"delivery_blocked",id);
            return; // retain due state for recovery when permissions return
        }
        DeviceStore.Device d;
        try(DeviceStore db=new DeviceStore(c)) {d=db.claim(id,System.currentTimeMillis());}
        if(d==null)return;
        try {
            boolean onTime="alarm".equals(origin)&&System.currentTimeMillis()-d.notificationAt()<120000;
            showDevice(c,d,true);
            EventLog.note(c,"delivered_"+origin,id);
            if(onTime&&Preferences.enabled(c,Preferences.SOUND))AlarmSoundService.start(c,id);
        }catch(RuntimeException problem) {
            try(DeviceStore db=new DeviceStore(c)){db.resetClaim(id);}
            EventLog.note(c,"delivery_failed",id);
            android.util.Log.w("BatteryCare","Could not post battery reminder",problem);
        }
    }
    static final String ACTION_TEST="com.batterycare.app.TEST_ALARM";
    static void showTest(Context c) {
        if(!canNotify(c)) {
            android.widget.Toast.makeText(c,"Enable app notifications first",android.widget.Toast.LENGTH_LONG).show();return;
        }
        ensureChannels(c);
        NotificationManager n=c.getSystemService(NotificationManager.class);
        Notification test=new Notification.Builder(c,dueChannel(c))
           .setSmallIcon(R.drawable.ic_battery).setContentTitle("Battery Care · Test reminder")
           .setContentText("This test did not change any device schedule")
           .setContentIntent(open(c,0)).setAutoCancel(true)
           .setCategory(Notification.CATEGORY_REMINDER).build();
        n.notify("battery-test",887766,test);
    }
    static void scheduleTest(Context c) {
        AlarmManager alarms=c.getSystemService(AlarmManager.class);
        if(alarms==null)return;
        Intent i=new Intent(c,ReminderReceiver.class).setAction(ACTION_TEST)
           .setData(Uri.parse("batterycare://test/60"));
        PendingIntent pending=PendingIntent.getBroadcast(c,8008,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        long when=System.currentTimeMillis()+60_000L;
        try {
            if(canExact(c))alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pending);
            else alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pending);
            android.widget.Toast.makeText(c,canExact(c)?"Test set for 60 seconds":"Test scheduled; may be delayed without exact alarm access",android.widget.Toast.LENGTH_LONG).show();
        }catch(SecurityException denied){
            alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pending);
        }
    }

}
