package com.batterycare.app;

import android.content.Context;
import android.content.SharedPreferences;

final class Preferences {
    static final String POPUP="popup", SOUND="sound", WATCH="watch", STATUS="status", ALARM_CLOCK="alarm_clock";
    private Preferences() {}
    static SharedPreferences store(Context c){return c.getSharedPreferences("battery_care_settings",Context.MODE_PRIVATE);}
    static boolean enabled(Context c,String name) {
        boolean defaultValue = !SOUND.equals(name) && !ALARM_CLOCK.equals(name) && !STATUS.equals(name);
        return store(c).getBoolean(name,defaultValue);
    }
    static void set(Context c,String name,boolean value) {store(c).edit().putBoolean(name,value).apply();}
}
