package com.batterycare.app;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

/** All battery records remain local on the phone. Manual percentages are optional. */
public final class DeviceStore extends SQLiteOpenHelper {
    private static final int DB_VERSION = 1;
    static final long DAY = 86_400_000L;
    static final String[] TYPES = {"Android handheld","Windows handheld","Retro handheld","Controller","Other"};
    static final String[] KINDS = {"Built-in rechargeable","Removable rechargeable","Rechargeable AA/AAA","Disposable AA/AAA","No battery"};
    static final String[] MODES = {"Powered off","Sleeping","Hibernate","Stored without cells"};
    public DeviceStore(Context context) { super(context,"batterycare.db",null,DB_VERSION); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE devices(_id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "name TEXT NOT NULL, category TEXT NOT NULL, kind TEXT NOT NULL, mode TEXT NOT NULL,"+
                "interval_days INTEGER NOT NULL, next_at INTEGER NOT NULL, last_at INTEGER NOT NULL DEFAULT 0,"+
                "level INTEGER NOT NULL DEFAULT -1, level_at INTEGER NOT NULL DEFAULT 0, early_hours INTEGER NOT NULL DEFAULT 0,"+
                "reminded_at INTEGER NOT NULL DEFAULT 0, snooze_until INTEGER NOT NULL DEFAULT 0,"+
                "enabled INTEGER NOT NULL DEFAULT 1, notes TEXT NOT NULL DEFAULT '')");
        db.execSQL("CREATE TABLE checks(_id INTEGER PRIMARY KEY AUTOINCREMENT,device_id INTEGER NOT NULL,"+
                "checked_at INTEGER NOT NULL,level INTEGER NOT NULL,mode TEXT NOT NULL,"+
                "prev_next_at INTEGER NOT NULL DEFAULT 0,prev_last_at INTEGER NOT NULL DEFAULT 0,"+
                "prev_level INTEGER NOT NULL DEFAULT -1,prev_level_at INTEGER NOT NULL DEFAULT 0,prev_reminded_at INTEGER NOT NULL DEFAULT 0,"+
                "prev_snooze_until INTEGER NOT NULL DEFAULT 0,FOREIGN KEY(device_id) REFERENCES devices(_id))");
        db.execSQL("CREATE INDEX idx_checks_device ON checks(device_id,checked_at DESC)");
        seed(db);
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { /* additive migrations in future versions */ }
    private void seed(SQLiteDatabase db) {
        addSeed(db,"AYN Thor","Android handheld","Built-in rechargeable","Sleeping",1);
        addSeed(db,"AYN Odin 3","Android handheld","Built-in rechargeable","Powered off",30);
        addSeed(db,"AYN Odin 3 Portal","Android handheld","Built-in rechargeable","Powered off",30);
        addSeed(db,"AYN Odin 2 Portal","Android handheld","Built-in rechargeable","Powered off",30);
        addSeed(db,"Retroid Pocket Classic","Android handheld","Built-in rechargeable","Powered off",30);
        addSeed(db,"Retroid Pocket Flip 2","Android handheld","Built-in rechargeable","Powered off",30);
        addSeed(db,"Retroid Pocket Nova","Android handheld","Built-in rechargeable","Powered off",30);
        addSeed(db,"MSI Claw 8 AI+","Windows handheld","Built-in rechargeable","Hibernate",14);
        addSeed(db,"Lenovo Legion Go S","Windows handheld","Built-in rechargeable","Hibernate",14);
        addSeed(db,"Konkr Pocket Advance","Android handheld","Built-in rechargeable","Powered off",30);
        addSeed(db,"PlayStation Portal","Android handheld","Built-in rechargeable","Powered off",30);
        addSeed(db,"Nintendo 2DS","Retro handheld","Removable rechargeable","Powered off",45);
        addSeed(db,"Nintendo 3DS","Retro handheld","Removable rechargeable","Powered off",45);
        addSeed(db,"Nintendo 3DS XL","Retro handheld","Removable rechargeable","Powered off",45);
    }
    private void addSeed(SQLiteDatabase db,String name,String category,String kind,String mode,int days) {
        ContentValues v=new ContentValues();v.put("name",name);v.put("category",category);
        v.put("kind",kind);v.put("mode",mode);v.put("interval_days",days);
        v.put("next_at",BatteryMath.nextCheckAt(System.currentTimeMillis(),days));db.insertOrThrow("devices",null,v);
    }
    public static final class Device {
        public long id,nextAt,lastAt,levelAt,remindedAt,snoozeUntil;
        public String name,category,kind,mode,notes;
        public int days,level,earlyHours;
        public boolean enabled;
        public long notificationAt() {
            long warnMs=Math.min(earlyHours*3600000L,Math.max(0,days*DAY-3600000L));
            return snoozeUntil>0?snoozeUntil:nextAt-warnMs;
        }
        public boolean due(long now) { return enabled && (remindedAt>0 || notificationAt()<=now); }
    }
    private Device read(Cursor c) {
        Device d=new Device();d.id=c.getLong(c.getColumnIndexOrThrow("_id"));
        d.name=c.getString(c.getColumnIndexOrThrow("name"));
        d.category=c.getString(c.getColumnIndexOrThrow("category"));
        d.kind=c.getString(c.getColumnIndexOrThrow("kind"));
        d.mode=c.getString(c.getColumnIndexOrThrow("mode"));
        d.notes=c.getString(c.getColumnIndexOrThrow("notes"));
        d.days=c.getInt(c.getColumnIndexOrThrow("interval_days"));
        d.nextAt=c.getLong(c.getColumnIndexOrThrow("next_at"));
        d.lastAt=c.getLong(c.getColumnIndexOrThrow("last_at"));
        d.remindedAt=c.getLong(c.getColumnIndexOrThrow("reminded_at"));
        d.snoozeUntil=c.getLong(c.getColumnIndexOrThrow("snooze_until"));
        d.level=c.getInt(c.getColumnIndexOrThrow("level"));
        d.levelAt=c.getLong(c.getColumnIndexOrThrow("level_at"));
        d.earlyHours=c.getInt(c.getColumnIndexOrThrow("early_hours"));
        d.enabled=c.getInt(c.getColumnIndexOrThrow("enabled"))==1;
        return d;
    }
    public synchronized List<Device> all() {
        List<Device> result=new ArrayList<>();
        try(Cursor c=getReadableDatabase().query("devices",null,null,null,null,null,"enabled DESC, next_at ASC, name COLLATE NOCASE")) {
            while(c.moveToNext())result.add(read(c));
        }
        return result;
    }
    public synchronized Device get(long id) {
        try(Cursor c=getReadableDatabase().query("devices",null,"_id=?",new String[]{""+id},null,null,null)) {
            return c.moveToFirst()?read(c):null;
        }
    }
    public synchronized long save(Device d) {
        if(d.name==null||d.name.trim().isEmpty())throw new IllegalArgumentException("Name required");
        ContentValues v=new ContentValues();v.put("name",d.name.trim());v.put("category",d.category);
        v.put("kind",d.kind);v.put("mode",d.mode);v.put("interval_days",Math.max(0,d.days));
        v.put("early_hours",Math.max(0,Math.min(d.earlyHours,72)));
        v.put("enabled",d.enabled&&d.days>0?1:0);v.put("notes",d.notes==null?"":d.notes);
        SQLiteDatabase db=getWritableDatabase();
        if(d.id<=0) {
            v.put("next_at",BatteryMath.nextCheckAt(System.currentTimeMillis(),Math.max(1,d.days)));
            return db.insertOrThrow("devices",null,v);
        }
        // Changed interval schedules from now only when nextAt isn't already imminent.
        Device prior=get(d.id);
        if(prior==null)throw new IllegalArgumentException("Device no longer exists");
        if(prior.days!=d.days || !prior.mode.equals(d.mode)) {
            v.put("next_at",BatteryMath.nextCheckAt(System.currentTimeMillis(),Math.max(1,d.days)));
            v.put("reminded_at",0);v.put("snooze_until",0);
        }
        db.update("devices",v,"_id=?",new String[]{""+d.id});return d.id;
    }
    public synchronized void delete(long id) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {db.delete("checks","device_id=?",new String[]{""+id});db.delete("devices","_id=?",new String[]{""+id});db.setTransactionSuccessful();}
        finally{db.endTransaction();}
    }
    public synchronized Device complete(long id,int level) {
        Device d=get(id);if(d==null)return null;
        long now=System.currentTimeMillis();
        int measured=level>=0?BatteryMath.clampLevel(level):-1;
        ContentValues v=new ContentValues();v.put("last_at",now);
        if(measured>=0){v.put("level",measured);v.put("level_at",now);}
        v.put("next_at",BatteryMath.nextCheckAt(now,Math.max(1,d.days)));
        v.put("reminded_at",0);v.put("snooze_until",0);
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {
            db.update("devices",v,"_id=?",new String[]{""+id});
            ContentValues checked=new ContentValues();checked.put("device_id",id);
            checked.put("checked_at",now);checked.put("level",measured);checked.put("mode",d.mode);
            checked.put("prev_next_at",d.nextAt);checked.put("prev_last_at",d.lastAt);
            checked.put("prev_level",d.level);checked.put("prev_level_at",d.levelAt);checked.put("prev_reminded_at",d.remindedAt);
            checked.put("prev_snooze_until",d.snoozeUntil);
            db.insertOrThrow("checks",null,checked);db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        return get(id);
    }
    /** Undo only the latest check, only during the 10-second notification window. */
    public synchronized Device undo(long id) {
        SQLiteDatabase db=getWritableDatabase();
        long now=System.currentTimeMillis();
        db.beginTransaction();
        try(Cursor c=db.query("checks",new String[]{"_id","checked_at","prev_next_at","prev_last_at","prev_level","prev_level_at","prev_reminded_at","prev_snooze_until"},
                    "device_id=?",new String[]{""+id},null,null,"checked_at DESC","1")) {
            if(!c.moveToFirst()||now-c.getLong(1)>10_000L)return null;
            long checkId=c.getLong(0);
            ContentValues update=new ContentValues();
            update.put("next_at",c.getLong(2));update.put("last_at",c.getLong(3));
            update.put("level",c.getInt(4));update.put("level_at",c.getLong(5));
            update.put("reminded_at",c.getLong(6));update.put("snooze_until",c.getLong(7));
            db.update("devices",update,"_id=?",new String[]{""+id});
            db.delete("checks","_id=?",new String[]{""+checkId});
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        return get(id);
    }
    public synchronized void snooze(long id,long until) {
        if(until<=System.currentTimeMillis())throw new IllegalArgumentException("Snooze must be in future");
        ContentValues v=new ContentValues();v.put("snooze_until",until);v.put("reminded_at",0);
        getWritableDatabase().update("devices",v,"_id=?",new String[]{""+id});
    }
    /** Claim once; if notifications are blocked the reminder stays unclaimed. */
    public synchronized Device claim(long id,long now) {
        Device d=get(id);
        if(d==null||!d.enabled||d.days<=0||d.remindedAt>0||d.notificationAt()>now)return null;
        ContentValues v=new ContentValues();v.put("reminded_at",now);
        if(getWritableDatabase().update("devices",v,"_id=? AND reminded_at=0",new String[]{""+id})!=1)return null;
        return get(id);
    }
    public synchronized void resetClaim(long id) {
        ContentValues v=new ContentValues();v.put("reminded_at",0);
        getWritableDatabase().update("devices",v,"_id=?",new String[]{""+id});
    }
    public static final class Check {
        public long time; public int level;public String mode;
    }
    public synchronized List<Check> history(long id,int limit) {
        List<Check> all=new ArrayList<>();
        try(Cursor c=getReadableDatabase().query("checks",new String[]{"checked_at","level","mode"},"device_id=?",new String[]{""+id},null,null,"checked_at DESC", ""+Math.max(1,Math.min(100,limit)))){
            while(c.moveToNext()){Check x=new Check();x.time=c.getLong(0);x.level=c.getInt(1);x.mode=c.getString(2);all.add(x);}
        }
        return all;
    }
    public static Device newDevice() {
        Device d=new Device();d.id=0;d.name="";d.category=TYPES[0];d.kind=KINDS[0];
        d.mode=MODES[0];d.days=30;d.level=-1;d.enabled=true;d.notes="";
        return d;
    }
}
