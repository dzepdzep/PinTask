package com.batterycare.app;

import android.content.Context;
import java.text.DateFormat;
import java.util.Date;

/** Bounded, private reminder diagnostics (last 100 events). */
final class EventLog {
    private EventLog() {}
    static synchronized void note(Context c,String event,long id){
        String line=DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.MEDIUM)
            .format(new Date())+" · "+event+(id>0?" #"+id:"");
        String old=c.getSharedPreferences("batterycare_events",Context.MODE_PRIVATE).getString("log","");
        String[] lines=old.split("\\n");
        StringBuilder next=new StringBuilder(line);
        for(int i=0;i<lines.length&&i<99;i++)if(!lines[i].isEmpty())next.append('\n').append(lines[i]);
        c.getSharedPreferences("batterycare_events",Context.MODE_PRIVATE)
            .edit().putString("log",next.toString()).apply();
    }
    static String recent(Context c){
        String s=c.getSharedPreferences("batterycare_events",Context.MODE_PRIVATE).getString("log","");
        return s.isEmpty()?"No reminders have been scheduled or delivered yet.":s;
    }
}
