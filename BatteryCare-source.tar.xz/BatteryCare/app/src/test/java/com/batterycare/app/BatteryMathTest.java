package com.batterycare.app;

import org.junit.Test;
import static org.junit.Assert.*;

public final class BatteryMathTest {
    @Test public void fastSleepDrainShortensChecks(){
        double rate=BatteryMath.drainPerDay(90,45,100000000L,100000000L+2*86400000L);
        assertEquals(22.5,rate,0.001);
        assertEquals(1,BatteryMath.drainBasedSuggestion(45,rate,30));
    }
    @Test public void refusesInvalidReadings(){
        assertTrue(Double.isNaN(BatteryMath.drainPerDay(-1,50,1L,86400001L)));
        assertTrue(Double.isNaN(BatteryMath.drainPerDay(20,80,1L,86400001L)));
        assertTrue(Double.isNaN(BatteryMath.drainPerDay(60,40,1L,2L)));
    }
    @Test public void neverLengthensChosenReminder(){
        assertEquals(3,BatteryMath.drainBasedSuggestion(90,0.1,3));
    }
    @Test public void keepsLocalTimeAcrossDstTransition(){
        java.time.ZoneId berlin=java.time.ZoneId.of("Europe/Berlin");
        long start=java.time.ZonedDateTime.of(2026,10,24,9,0,0,0,berlin).toInstant().toEpochMilli();
        long next=BatteryMath.nextCheckAt(start,3,berlin);
        assertEquals(9,java.time.Instant.ofEpochMilli(next).atZone(berlin).getHour());
        assertEquals(27,java.time.Instant.ofEpochMilli(next).atZone(berlin).getDayOfMonth());
    }
    @Test public void poweredOffConversionOnlyChangesOriginalPresets(){
        assertEquals(7,BatteryMath.poweredOffInterval("AYN Thor","Android handheld","Sleeping",1));
        assertEquals(30,BatteryMath.poweredOffInterval("AYN Odin 3","Android handheld","Sleeping",3));
        assertEquals(30,BatteryMath.poweredOffInterval("MSI Claw 8 AI+","Windows handheld","Hibernate",14));
        assertEquals(30,BatteryMath.poweredOffInterval("Legion Go S","Windows handheld","Sleeping",1));
        assertEquals(2,BatteryMath.poweredOffInterval("AYN Thor","Android handheld","Sleeping",2));
        assertEquals(14,BatteryMath.poweredOffInterval("Other","Controller","Hibernate",14));
        assertEquals(45,BatteryMath.poweredOffInterval("Nintendo 3DS","Retro handheld","Powered off",45));
    }
    @Test public void controllerAndSleepPresets(){
        assertEquals(90,BatteryMath.suggestedInterval("Controller","Built-in rechargeable","Powered off"));
        assertEquals(1,BatteryMath.suggestedInterval("AYN Thor","Android handheld","Built-in rechargeable","Sleeping"));
        assertEquals(7,BatteryMath.poweredOffInterval("AYN Thor","Android handheld","Powered off",7));
        assertEquals(3,BatteryMath.suggestedInterval("Android handheld","Built-in rechargeable","Sleeping"));
        assertEquals(0,BatteryMath.suggestedInterval("Controller","No battery","Powered off"));
        assertEquals(0,BatteryMath.suggestedInterval("Controller","Disposable AA/AAA","Stored without cells"));
    }
}
