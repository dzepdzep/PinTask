package com.batterycare.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.text.DateFormat;
import java.util.*;

/** Standalone UI: local checklist, schedules, controllers, history, health and settings. */
public final class MainActivity extends Activity {
    private static final int BG=Color.rgb(16,19,29), PANEL=Color.rgb(32,38,55);
    private static final int PANEL2=Color.rgb(42,49,70), TEXT=Color.rgb(245,247,255);
    private static final int MUTED=Color.rgb(171,184,210), BLUE=Color.rgb(158,181,255);
    private static final int GREEN=Color.rgb(149,224,182), RED=Color.rgb(255,170,152);
    private static final int EXPORT=201, IMPORT=202, NOTIFY=203;
    private LinearLayout body;
    private String filter="All";
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Reminders.ensureChannels(this);RecoveryJob.ensure(this);
        Reminders.deliverDue(this,"launch");Reminders.rescheduleAll(this);Reminders.sync(this);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFY);
        if(!Preferences.store(this).getBoolean("setup_seen",false)){
            Preferences.store(this).edit().putBoolean("setup_seen",true).apply();
            new Handler(Looper.getMainLooper()).postDelayed(()->{
                if(!isFinishing()&&!isDestroyed())
                    new AlertDialog.Builder(this).setTitle("Set up reliable battery reminders")
                        .setMessage("Battery Care needs notifications and, for precise scheduled alerts, Android's Alarms & reminders access. Some manufacturers also restrict background work. Review these settings, then run the 60-second test with your phone locked.")
                        .setNegativeButton("Later",null)
                        .setPositiveButton("Review",(d,w)->health()).show();
            },750);
        }
        showHome();
        handleIntent(getIntent());
    }
    @Override public void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);handleIntent(i);}
    private void handleIntent(Intent i){
        if(i==null)return;
        if("com.batterycare.app.ADD".equals(i.getAction())){
            edit(DeviceStore.newDevice());return;
        }
        long device=i.getLongExtra(Reminders.EXTRA_ID,0);
        if(device>0){try(DeviceStore db=new DeviceStore(this)){
            DeviceStore.Device d=db.get(device);if(d!=null)detail(d);
        }}
    }
    @Override public void onResume(){
        super.onResume();Reminders.deliverDue(this,"resume");Reminders.rescheduleAll(this);
        if(body!=null)showHome();
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){
        super.onRequestPermissionsResult(request,permissions,results);
        if(request==NOTIFY){Reminders.deliverDue(this,"permission");Reminders.rescheduleAll(this);showHome();}
    }
    private int dp(float n){return Math.round(getResources().getDisplayMetrics().density*n);}
    private GradientDrawable bg(int color,int radius){
        GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;
    }
    private GradientDrawable outline(int color,int radius,int stroke){
        GradientDrawable g=bg(color,radius);g.setStroke(dp(1),stroke);return g;
    }
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);
        t.setFontFeatureSettings("kern");if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }
    private void pad(View v,int a,int b,int c,int d){v.setPadding(dp(a),dp(b),dp(c),dp(d));}
    private LinearLayout.LayoutParams margins(int w,int h,int top){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));p.topMargin=dp(top);return p;
    }
    private TextView button(String s,boolean primary,Runnable click){
        TextView b=text(s,14,primary?BG:BLUE,true);b.setGravity(Gravity.CENTER);
        pad(b,12,10,12,10);b.setBackground(bg(primary?BLUE:PANEL2,11));
        b.setClickable(true);b.setOnClickListener(v->click.run());
        return b;
    }
    private void root(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(BG);
        body=col();pad(body,18,22,18,28);sc.addView(body);setContentView(sc);
    }
    private void section(String title,String description){
        body.addView(text(title,21,TEXT,true),margins(-1,-2,24));
        if(description!=null)body.addView(text(description,13,MUTED,false),margins(-1,-2,6));
    }
    private void showHome(){
        root();
        LinearLayout head=row();
        LinearLayout heading=col();
        heading.addView(text("BATTERY CARE",13,BLUE,true));
        heading.addView(text("Your collection",30,TEXT,true));
        head.addView(heading,new LinearLayout.LayoutParams(0,-2,1));
        head.addView(button("⚙  Settings",false,this::settings));body.addView(head);
        List<DeviceStore.Device> all;
        try(DeviceStore db=new DeviceStore(this)){all=db.all();}
        int active=0,due=0,controllers=0;long next=Long.MAX_VALUE;
        long now=System.currentTimeMillis();
        for(DeviceStore.Device d:all){if("Controller".equals(d.category))controllers++;
            if(d.enabled){active++;if(d.due(now))due++;else next=Math.min(next,d.notificationAt());}
        }
        LinearLayout tiles=row();tiles.setWeightSum(3);
        stat(tiles,""+active,"Tracked");stat(tiles,""+due,"Due now");stat(tiles,""+controllers,"Controllers");
        body.addView(tiles,margins(-1,-2,22));
        TextView tip=text(due>0?"You have "+due+" battery check"+(due==1?"":"s")+" to complete":
            "Next check: "+(next==Long.MAX_VALUE?"Nothing scheduled":Reminders.when(next)),14,due>0?RED:GREEN,true);
        pad(tip,14,14,14,14);tip.setBackground(bg(PANEL,12));body.addView(tip);
        LinearLayout tabs=row();tabs.setWeightSum(4);
        for(String tab:new String[]{"All","Due","Handhelds","Controllers"}){
            TextView b=text(tab,12,filter.equals(tab)?TEXT:MUTED,filter.equals(tab));
            b.setGravity(Gravity.CENTER);pad(b,5,12,5,12);
            b.setBackground(bg(filter.equals(tab)?PANEL2:BG,9));
            tabs.addView(b,new LinearLayout.LayoutParams(0,-2,1));
            b.setOnClickListener(v->{filter=tab;showHome();});
        }
        body.addView(tabs,margins(-1,-2,17));
        LinearLayout add=row();add.addView(text("Devices",20,TEXT,true),new LinearLayout.LayoutParams(0,-2,1));
        add.addView(button("+ Add device",true,()->edit(DeviceStore.newDevice())));
        body.addView(add,margins(-1,-2,4));
        int shown=0;
        for(DeviceStore.Device d:all){
            if("Due".equals(filter)&&!d.due(now))continue;
            if("Controllers".equals(filter)&&!"Controller".equals(d.category))continue;
            if("Handhelds".equals(filter)&&"Controller".equals(d.category))continue;
            showCard(d);shown++;
        }
        if(shown==0){TextView empty=text("No devices in this view. Tap + Add device to start tracking one.",14,MUTED,false);
            pad(empty,16,25,16,25);body.addView(empty);}
        TextView footer=text("Battery levels are manually entered. A sleeping or powered-off handheld cannot normally report its charge to another phone.",12,MUTED,false);
        body.addView(footer,margins(-1,-2,26));
    }
    private void stat(LinearLayout dest,String number,String label){
        LinearLayout panel=col();panel.setGravity(Gravity.CENTER);pad(panel,8,16,8,16);panel.setBackground(bg(PANEL,12));
        TextView n=text(number,24,TEXT,true);n.setGravity(Gravity.CENTER);
        TextView l=text(label,11,MUTED,false);l.setGravity(Gravity.CENTER);
        panel.addView(n);panel.addView(l);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.rightMargin=dp(6);dest.addView(panel,p);
    }
    private void showCard(DeviceStore.Device d){
        long now=System.currentTimeMillis();
        LinearLayout card=col();pad(card,15,15,15,14);
        card.setBackground(outline(PANEL,15,d.due(now)?RED:PANEL2));
        LinearLayout h=row();
        String icon="Controller".equals(d.category)?"◈":"▣";
        TextView glyph=text(icon,26,BLUE,true);h.addView(glyph,margins(36,-2,0));
        LinearLayout info=col();info.addView(text(d.name,16,TEXT,true));
        info.addView(text(d.category+" · "+d.mode,12,MUTED,false));
        h.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        TextView indicator=text(!d.enabled?"OFF":d.due(now)?"DUE":d.level>=0?d.level+"%":"—",13,
            !d.enabled?MUTED:d.due(now)?RED:d.level>=0&&d.level<30?RED:GREEN,true);
        h.addView(indicator);card.addView(h);
        String when=d.due(now)?"Check needed now":("Next check · "+Reminders.when(d.notificationAt()));
        TextView line=text(when+"  ·  Every "+d.days+" days",12,d.due(now)?RED:MUTED,false);
        card.addView(line,margins(-1,-2,12));
        LinearLayout actions=row();
        TextView checked=button("✓  Log check",true,()->log(d));
        actions.addView(checked,new LinearLayout.LayoutParams(0,-2,1));
        TextView more=button("Details  ···",false,()->detail(d));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.leftMargin=dp(7);actions.addView(more,p);
        card.addView(actions,margins(-1,-2,13));
        body.addView(card,margins(-1,-2,9));
    }
    private void detail(DeviceStore.Device d){
        DeviceStore.Device current;
        try(DeviceStore db=new DeviceStore(this)){current=db.get(d.id);}
        if(current==null)return;
        List<String> options=new ArrayList<>(Arrays.asList("Log battery check","Edit device and schedule","Snooze…","Battery history","Check now (show reminder)","Delete device"));
        new AlertDialog.Builder(this).setTitle(current.name)
            .setItems(options.toArray(new String[0]),(dialog,which)->{
                switch(which){
                    case 0:log(current);break;
                    case 1:edit(current);break;
                    case 2: startActivity(new Intent(this,SnoozeActivity.class).putExtra(Reminders.EXTRA_ID,current.id));break;
                    case 3:history(current);break;
                    case 4:
                        try(DeviceStore db=new DeviceStore(this)){db.resetClaim(current.id);db.snooze(current.id,System.currentTimeMillis()+1000);}
                        Reminders.cancelScheduled(this,current.id);Reminders.schedule(this,currentFor(current.id));
                        Toast.makeText(this,"Reminder scheduled in a moment",Toast.LENGTH_SHORT).show();break;
                    case 5:delete(current);break;
                }
            }).setPositiveButton("Close",null).show();
    }
    private DeviceStore.Device currentFor(long id){try(DeviceStore db=new DeviceStore(this)){return db.get(id);}}
    private void log(DeviceStore.Device d){
        EditText level=new EditText(this);level.setSingleLine(true);level.setInputType(InputType.TYPE_CLASS_NUMBER);
        level.setHint("Optional · 0–100%");pad(level,20,12,20,12);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Checked · "+d.name)
            .setMessage("Enter the battery percentage if known. Leave empty to complete without recording a new reading.")
            .setView(level).setNegativeButton("Cancel",null).setPositiveButton("Complete",null).create();
        dialog.setOnShowListener(v->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(btn->{
            int value=-1;String typed=level.getText().toString().trim();
            if(!typed.isEmpty())try{value=Integer.parseInt(typed);}catch(NumberFormatException e){level.setError("Use 0 to 100");return;}
            if(value>100||value< -1){level.setError("Use 0 to 100");return;}
            double observed=Double.NaN;
            if(value>=0&&d.level>=0&&d.levelAt>0)observed=BatteryMath.drainPerDay(d.level,value,d.levelAt,System.currentTimeMillis());
            DeviceStore.Device next;
            try(DeviceStore db=new DeviceStore(this)){next=db.complete(d.id,value);}
            AlarmSoundService.stopFor(this,d.id);Reminders.cancelScheduled(this,d.id);Reminders.cancel(this,d.id);Reminders.schedule(this,next);
            dialog.dismiss();showHome();
            if(next!=null && Double.isFinite(observed)){
                int suggestion=BatteryMath.drainBasedSuggestion(value,observed,next.days);
                String summary=String.format(Locale.getDefault(),"Observed drain: %.1f%% per day.\n",observed);
                if(suggestion<next.days){
                    new AlertDialog.Builder(this).setTitle("Battery drain detected")
                        .setMessage(summary+"Consider checking every "+suggestion+" day(s) instead of "+next.days+". Readings can vary with sleep mode and background activity.")
                        .setNegativeButton("Keep schedule",null)
                        .setPositiveButton("Use "+suggestion+" day(s)",(x,w)->{
                            next.days=suggestion;
                            try(DeviceStore db=new DeviceStore(this)){db.save(next);}
                            Reminders.cancelScheduled(this,next.id);Reminders.schedule(this,currentFor(next.id));showHome();
                        }).show();
                }else Toast.makeText(this,summary.trim(),Toast.LENGTH_LONG).show();
            }
        }));
        dialog.show();
    }
    private void delete(DeviceStore.Device d){
        new AlertDialog.Builder(this).setTitle("Delete "+d.name+"?")
            .setMessage("This permanently deletes this device and its local history.")
            .setNegativeButton("Keep",null).setPositiveButton("Delete",(x,w)->{
                AlarmSoundService.stopFor(this,d.id);Reminders.cancelScheduled(this,d.id);Reminders.cancel(this,d.id);
                try(DeviceStore db=new DeviceStore(this)){db.delete(d.id);}
                showHome();
            }).show();
    }
    private void history(DeviceStore.Device d){
        StringBuilder b=new StringBuilder();
        try(DeviceStore db=new DeviceStore(this)){
            List<DeviceStore.Check> checks=db.history(d.id,50);
            if(checks.isEmpty())b.append("No battery checks recorded yet.");
            for(DeviceStore.Check c:checks){b.append(Reminders.when(c.time)).append(" · ")
                .append(c.level<0?"No new percentage":c.level+"%").append(" · ").append(c.mode).append("\n\n");}
        }
        new AlertDialog.Builder(this).setTitle(d.name+" · Check history").setMessage(b.toString())
            .setPositiveButton("Close",null).show();
    }
    private TextView fieldLabel(String s){TextView t=text(s,13,MUTED,true);pad(t,0,14,0,3);return t;}
    private EditText field(String value,boolean numeric){
        EditText e=new EditText(this);e.setText(value);e.setTextColor(TEXT);e.setHintTextColor(MUTED);
        if(numeric)e.setInputType(InputType.TYPE_CLASS_NUMBER);e.setSingleLine(true);
        e.setTextSize(16);pad(e,10,9,10,9);e.setBackground(outline(PANEL2,9,PANEL));return e;
    }
    private Spinner spinner(String[] opts,String selected){
        Spinner s=new Spinner(this);ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,opts);
        s.setAdapter(a);
        int idx=Arrays.asList(opts).indexOf(selected);s.setSelection(Math.max(0,idx));return s;
    }
    private void edit(DeviceStore.Device d){
        ScrollView sc=new ScrollView(this);LinearLayout form=col();pad(form,18,4,18,12);sc.addView(form);
        form.addView(fieldLabel("Device name"));EditText name=field(d.name,false);name.setHint("e.g. Xbox Wireless Controller");form.addView(name);
        form.addView(fieldLabel("Device type"));Spinner type=spinner(DeviceStore.TYPES,d.category);form.addView(type);
        form.addView(fieldLabel("Battery type"));Spinner kind=spinner(DeviceStore.KINDS,d.kind);form.addView(kind);
        form.addView(fieldLabel("Storage state"));Spinner mode=spinner(DeviceStore.MODES,d.mode);form.addView(mode);
        form.addView(fieldLabel("Check interval (days, 1–365)"));EditText days=field(""+d.days,true);form.addView(days);
        TextView recommend=button("Suggest an interval for this setup",false,()->{
            String category=""+type.getSelectedItem(),battery=""+kind.getSelectedItem(),status=""+mode.getSelectedItem();
            int suggested=BatteryMath.suggestedInterval(category,battery,status);
            if(suggested==0){days.setText("0");Toast.makeText(this,"No battery: reminders will be disabled",Toast.LENGTH_LONG).show();}
            else days.setText(""+suggested);
        });form.addView(recommend,margins(-1,-2,8));
        form.addView(fieldLabel("Early warning (hours before due, 0–72)"));
        EditText early=field(""+d.earlyHours,true);form.addView(early);
        form.addView(fieldLabel("Notes (optional)"));EditText notes=field(d.notes,false);notes.setSingleLine(false);form.addView(notes);
        CheckBox enabled=new CheckBox(this);enabled.setText("Enable reminder schedule");enabled.setTextColor(TEXT);enabled.setChecked(d.enabled);form.addView(enabled,margins(-1,-2,8));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle(d.id==0?"Add a device":"Edit device")
            .setView(sc).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();
        dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String title=name.getText().toString().trim();if(title.isEmpty()){name.setError("Enter a name");return;}
            if("Stored without cells".equals(mode.getSelectedItem()) &&
                !((""+kind.getSelectedItem()).contains("AA/AAA")||"No battery".equals(kind.getSelectedItem()))) {
                Toast.makeText(this,"Only removable AA/AAA cells can be stored separately",Toast.LENGTH_LONG).show();return;
            }
            int interval,warning;
            try{interval=Integer.parseInt(days.getText().toString());warning=Integer.parseInt(early.getText().toString());}
            catch(NumberFormatException bad){days.setError("Enter a number");return;}
            if(interval<0||interval>365||warning<0||warning>72){days.setError("Interval 0–365; warning 0–72");return;}
            d.name=title;d.category=""+type.getSelectedItem();d.kind=""+kind.getSelectedItem();d.mode=""+mode.getSelectedItem();
            d.days=interval;d.earlyHours=warning;d.notes=notes.getText().toString();d.enabled=enabled.isChecked()&&interval>0;
            try(DeviceStore db=new DeviceStore(this)){
                if(d.id>0){Reminders.cancelScheduled(this,d.id);Reminders.cancel(this,d.id);}
                d.id=db.save(d);
                Reminders.schedule(this,db.get(d.id));
            }
            Reminders.sync(this);
            dlg.dismiss();showHome();
        }));
        dlg.show();
    }
    private void settings(){
        String[] options={"Reminder health and permissions","Test reminder now","Test reminder in 60 seconds",
           "Direct 30-second alarm sound", "Pop-up notification banners","Show status icon only for due checks",
           "Alarm-clock priority (extra battery use)","Allow notifications on smartwatches",
           "Export backup…","Import backup…","Battery storage guidance"};
        new AlertDialog.Builder(this).setTitle("Battery Care · Settings")
            .setItems(options,(dialog,which)->{
                switch(which){
                    case 0:health();break;
                    case 1:Reminders.showTest(this);break;
                    case 2:Reminders.scheduleTest(this);break;
                    case 3:toggle(Preferences.SOUND,"Play a separate alarm ringtone for up to 30 seconds?");break;
                    case 4:toggle(Preferences.POPUP,"Enable heads-up banners for new battery alarms?");break;
                    case 5:toggle(Preferences.STATUS,"Show status icon only when a check needs attention?");break;
                    case 6:toggle(Preferences.ALARM_CLOCK,"Use Android alarm-clock priority (visible to Android, more intrusive and power-hungry)?");break;
                    case 7:toggle(Preferences.WATCH,"Allow notification mirroring to connected watches?");break;
                    case 8: Backup.exportPicker(this,EXPORT);break;
                    case 9: Backup.importPicker(this,IMPORT);break;
                    case 10:guide();break;
                }
            }).setPositiveButton("Close",null).show();
    }
    private void toggle(String key,String explanation){
        boolean current=Preferences.enabled(this,key);
        new AlertDialog.Builder(this).setTitle(current?"Currently ON":"Currently OFF").setMessage(explanation)
            .setNegativeButton("Cancel",null)
            .setPositiveButton(current?"Turn off":"Turn on",(d,w)->{
                Preferences.set(this,key,!current);
                if(Preferences.ALARM_CLOCK.equals(key))Reminders.rescheduleAll(this);
                Reminders.refreshStatus(this);Toast.makeText(this,"Saved",Toast.LENGTH_SHORT).show();
            }).show();
    }
    private void health(){
        AudioManager audio=getSystemService(AudioManager.class);
        int level=audio==null?-1:audio.getStreamVolume(AudioManager.STREAM_ALARM);
        boolean notifications=Reminders.canNotify(this),exact=Reminders.canExact(this);
        android.app.NotificationManager n=getSystemService(android.app.NotificationManager.class);
        android.app.NotificationChannel c=n==null?null:n.getNotificationChannel(Reminders.dueChannel(this));
        String content="App notifications: "+(notifications?"Enabled":"BLOCKED")+
            "\nAlarm channel: "+(c!=null&&c.getImportance()>0?"Enabled":"BLOCKED")+
            "\nExact alarms: "+(exact?"Allowed":"Not allowed (reminders may be delayed)")+
            "\nAlarm volume: "+(level==0?"MUTED":level<0?"Unknown":level)+
            "\nOptional direct ringtone: "+(Preferences.enabled(this,Preferences.SOUND)?"ON":"Off")+
            "\n\nAfter changing permissions, return to the app. No Android setting guarantees delivery on every heavily customized device.";
        new AlertDialog.Builder(this).setTitle("Reminder health").setMessage(content)
            .setNegativeButton("Close",null).setPositiveButton("Permissions & diagnostics",(dialog,choice)->{
                new AlertDialog.Builder(this).setTitle("Reminder actions")
                    .setItems(new String[]{"Open exact alarm access","Open notification settings","Open application battery settings","Recent reminder event log"},(dlg,which)->{
                        if(which==3){new AlertDialog.Builder(this).setTitle("Reminder diagnostics")
                            .setMessage(EventLog.recent(this)).setPositiveButton("Close",null).show();return;}
                        try{
                            Intent i;
                            if(which==0&&Build.VERSION.SDK_INT>=31){i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                                i.setData(android.net.Uri.parse("package:"+getPackageName()));}
                            else if(which==1){i=new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName());}
                            else{i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+getPackageName()));}
                            startActivity(i);
                        }catch(RuntimeException e){Toast.makeText(this,"System settings unavailable",Toast.LENGTH_LONG).show();}
                    }).setNegativeButton("Close",null).show();
            }).show();
    }
    private void guide(){new AlertDialog.Builder(this).setTitle("Battery storage guidance")
        .setMessage("For devices left unused for weeks, aim for about 40–60% charge, power off, and store somewhere cool and dry. Avoid long-term storage empty or hot. Check sleeping devices much more often.\n\nRechargeable controllers: turn off and inspect every few months. Disposable alkaline AA/AAA: remove for extended storage. No battery: disable battery reminders.\n\nSchedules are starting suggestions, not live readings. Never use the app as a substitute for checking a hot, swollen, or damaged battery.")
        .setPositiveButton("OK",null).show();}
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        if(request==EXPORT){try{Backup.write(this,data.getData());Toast.makeText(this,"Backup saved",Toast.LENGTH_LONG).show();}
            catch(Exception x){error(x);}}
        if(request==IMPORT){new AlertDialog.Builder(this).setTitle("Replace device collection?")
            .setMessage("Import replaces all current devices and check history. Make a backup first.")
            .setNegativeButton("Cancel",null).setPositiveButton("Import",(d,w)->{
                try{Backup.read(this,data.getData());Reminders.rescheduleAll(this);Reminders.sync(this);showHome();
                    Toast.makeText(this,"Backup imported",Toast.LENGTH_LONG).show();}
                catch(Exception x){error(x);}
            }).show();}
    }
    private void error(Exception e){new AlertDialog.Builder(this).setTitle("Could not complete action")
        .setMessage(e.getMessage()==null?"Unknown error":e.getMessage()).setPositiveButton("OK",null).show();}
}
