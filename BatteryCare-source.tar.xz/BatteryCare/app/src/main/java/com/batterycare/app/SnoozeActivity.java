package com.batterycare.app;

import android.app.*;
import android.os.Bundle;
import java.util.Calendar;

public final class SnoozeActivity extends Activity {
    private long id;
    @Override public void onCreate(Bundle b){super.onCreate(b);
        id=getIntent().getLongExtra(Reminders.EXTRA_ID,-1);
        if(id<=0){finish();return;}
        AlarmSoundService.stopFor(this,id);
        new AlertDialog.Builder(this).setTitle("Snooze battery check")
          .setItems(new String[]{"15 minutes","1 hour","Tomorrow","In 3 days","Choose date and time…"},(dialog,choice)->{
              Calendar c=Calendar.getInstance();
              if(choice==0)c.add(Calendar.MINUTE,15);
              else if(choice==1)c.add(Calendar.HOUR_OF_DAY,1);
              else if(choice==2)c.add(Calendar.DAY_OF_MONTH,1);
              else if(choice==3)c.add(Calendar.DAY_OF_MONTH,3);
              else{choose(c);return;}
              save(c.getTimeInMillis());
          }).setNegativeButton("Cancel",(d,w)->finish()).setOnCancelListener(d->finish()).show();
    }
    private void choose(Calendar c){
        DatePickerDialog date=new DatePickerDialog(this,(view,y,m,day)->{
            c.set(y,m,day);
            TimePickerDialog time=new TimePickerDialog(this,(tv,h,min)->{
                c.set(Calendar.HOUR_OF_DAY,h);c.set(Calendar.MINUTE,min);
                c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);save(c.getTimeInMillis());
            },c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),android.text.format.DateFormat.is24HourFormat(this));
            time.setOnCancelListener(d->finish());time.show();
        },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH));
        date.setOnCancelListener(d->finish());date.show();
    }
    private void save(long millis){
        if(millis<=System.currentTimeMillis()){
            android.widget.Toast.makeText(this,"Choose a future time",android.widget.Toast.LENGTH_LONG).show();finish();return;
        }
        try(DeviceStore db=new DeviceStore(this)){
            db.snooze(id,millis);
            Reminders.cancelScheduled(this,id);Reminders.cancel(this,id);
            Reminders.schedule(this,db.get(id));
        }finally{finish();}
    }
}
