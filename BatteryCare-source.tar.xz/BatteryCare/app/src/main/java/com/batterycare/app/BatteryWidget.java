package com.batterycare.app;

import android.app.PendingIntent;
import android.appwidget.*;
import android.content.*;
import android.net.Uri;
import android.widget.RemoteViews;
import java.util.List;

public final class BatteryWidget extends AppWidgetProvider {
    @Override public void onUpdate(Context c,AppWidgetManager mgr,int[] ids){update(c,mgr,ids);}
    @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager mgr,int id,android.os.Bundle opts){update(c,mgr,new int[]{id});}
    static void updateAll(Context c){
        AppWidgetManager mgr=AppWidgetManager.getInstance(c);
        int[] ids=mgr.getAppWidgetIds(new ComponentName(c,BatteryWidget.class));
        if(ids.length>0)update(c,mgr,ids);
    }
    private static void update(Context c,AppWidgetManager mgr,int[] ids){
        List<DeviceStore.Device> all;
        try(DeviceStore db=new DeviceStore(c)){all=db.all();}
        int enabled=0,due=0;DeviceStore.Device first=null;
        long now=System.currentTimeMillis();
        for(DeviceStore.Device d:all)if(d.enabled){enabled++;if(d.due(now)){due++;if(first==null)first=d;}}
        for(int id:ids){
            RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.battery_widget);
            v.setTextViewText(R.id.widget_title,"Battery Care · "+enabled+" devices");
            v.setTextViewText(R.id.widget_summary,due==0?"No battery checks due":
                due+" due · "+(first==null?"":first.name));
            Intent open=new Intent(c,MainActivity.class).setAction(Intent.ACTION_MAIN).setData(Uri.parse("batterycare://widget/open/"+id));
            v.setOnClickPendingIntent(R.id.widget_open,PendingIntent.getActivity(c,30000+id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
            Intent add=new Intent(c,QuickAddActivity.class).setAction("com.batterycare.app.ADD").setData(Uri.parse("batterycare://widget/add/"+id));
            v.setOnClickPendingIntent(R.id.widget_add,PendingIntent.getActivity(c,40000+id,add,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
            mgr.updateAppWidget(id,v);
        }
    }
}
