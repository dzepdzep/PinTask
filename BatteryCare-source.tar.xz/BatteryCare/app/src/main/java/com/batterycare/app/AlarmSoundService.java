package com.batterycare.app;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;

/** Opt-in, bounded audible alarm. No polling or always-running service. */
public final class AlarmSoundService extends Service {
    private static final String CHANNEL="battery_care_audio_v1";
    private static final int NOTICE_ID=889900;
    private static final String ACTION_PLAY="com.batterycare.app.PLAY_TONE";
    private final Handler handler=new Handler(Looper.getMainLooper());
    private Ringtone ringtone;
    private long playing;
    private static volatile long requested;
    private final Runnable timeout=this::stopSelf;

    static void start(Context c,long id) {
        if(id<=0||!Preferences.enabled(c,Preferences.SOUND)||!Reminders.canNotify(c))return;
        requested=id;
        try {
            c.startForegroundService(new Intent(c,AlarmSoundService.class)
                .setAction(ACTION_PLAY).putExtra(Reminders.EXTRA_ID,id));
        } catch(RuntimeException denied) {
            if(requested==id)requested=0;
            android.util.Log.w("BatteryCare","Foreground ringtone blocked; notification sound remains",denied);
        }
    }
    static void stopFor(Context c,long id) {
        if(id>0&&requested==id) {requested=0;c.stopService(new Intent(c,AlarmSoundService.class));}
    }
    @Override public void onCreate(){super.onCreate();
        NotificationManager n=getSystemService(NotificationManager.class);
        NotificationChannel ch=new NotificationChannel(CHANNEL,"Active battery alarm sound",NotificationManager.IMPORTANCE_LOW);
        ch.setSound(null,null);ch.enableVibration(false);n.createNotificationChannel(ch);
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if(intent==null||!ACTION_PLAY.equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
        long id=intent.getLongExtra(Reminders.EXTRA_ID,0);
        if(id<=0||id!=requested){stopSelf();return START_NOT_STICKY;}
        stopRingtone();playing=id;
        PendingIntent stop=Reminders.intent(this,Reminders.ACTION_STOP,id,PendingIntent.FLAG_UPDATE_CURRENT);
        Notification note=new Notification.Builder(this,CHANNEL)
          .setSmallIcon(R.drawable.ic_battery).setContentTitle("Battery Care alarm")
          .setContentText("Sound will stop after 30 seconds")
          .setContentIntent(Reminders.open(this,id))
          .addAction(new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this,R.drawable.ic_battery),"Stop sound",stop).build())
          .build();
        startForeground(NOTICE_ID,note);
        try {
            ringtone=RingtoneManager.getRingtone(this,RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));
            if(ringtone!=null) {
                ringtone.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                ringtone.play();
            }
        }catch(RuntimeException failure){android.util.Log.w("BatteryCare","Cannot play ringtone",failure);}
        handler.removeCallbacks(timeout);handler.postDelayed(timeout,30_000L);
        return START_NOT_STICKY;
    }
    private void stopRingtone() {
        handler.removeCallbacks(timeout);
        if(ringtone!=null)try{ringtone.stop();}catch(RuntimeException ignored){}
        ringtone=null;
    }
    @Override public void onDestroy(){stopRingtone();if(requested==playing)requested=0;super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
