# Battery Care (Android)

A separate, offline battery-maintenance reminder app for collections of handhelds and controllers. It is **not** a PinTask update or a shared PinTask database. No microphone, voice recognition, internet, Bluetooth scanning or accounts required.

**Status:** Initial standalone source project (v0.1.0). Source-level and pure-Java checks only in the current environment. APK build and on-device alarm tests still required. Android's alarm and background restrictions mean no software can promise a perfectly punctual reminder on every device.

## What's implemented

- Editable profiles: name, device type, battery chemistry/form, storage state, notes, reminder interval (days), optional early warning (hours), and enabled switch.
- 14 prefilled handheld records (including AYN Thor, Odin, Retroid, MSI, Lenovo, Konkr, PlayStation Portal, and 2DS/3DS). These are **starting assumptions**, not detected battery states. Confirm power modes and intervals on first launch; no controllers are invented.
- Controllers: built-in rechargeable, removable rechargeable, rechargeable AA/AAA, disposable AA/AAA, and no battery. Add each actual model yourself.
- Individual one-off schedules which recur from the moment **Checked** is pressed, not a hardcoded calendar cycle.
- PinTask-inspired: exact-when-permitted Android alarms with `setAndAllowWhileIdle` fallback, high-importance notification channel, optional 30s ringtone playback, Done/Checked + 10-second Undo + Snooze + Stop Sound, persistent due notifications (reposted after accidental dismissal), status icon only while checks are due, reboot/timezone/app-update rescheduling, 15-minute recovery job, optional watch mirroring and alarm-clock priority.
- Notification test now or in 60 seconds, alarm/notification settings review, home widget + lightweight typed Quick Add, local JSON export/import, optional battery percent history, and conservative drain warnings.
- Device percentages are **manual entries**. This app cannot automatically read the battery percentage of powered-off handhelds or disconnected controllers.

## Build (Android Studio)

Open the repository root in Android Studio with Android SDK 35 and JDK 17. Allow Gradle sync, then run `:app:assembleDebug` or `:app:testDebugUnitTest`. Install `app/build/outputs/apk/debug/app-debug.apk` on an Android phone. For repeatable CI builds, `.github/workflows/build-apk.yml` tests and uploads a debug APK when this project is hosted in a GitHub repository.

The APK has a **different application ID** (`com.batterycare.app`) from PinTask (`com.pintask.app`), so it can coexist with PinTask. Debug APKs are intended for testing; for regular updates, establish a stable release signing key and keep it backed up. Do not uninstall the app without first exporting your data.

## Initial checks after installation

1. Confirm prefilled devices, actual power-off/sleep modes, battery types, and check intervals; add controllers.
2. Grant notification permission and review **Alarms & reminders** access, notification channels and manufacturer background restrictions in Settings > Reminder health.
3. Enable direct ringtone only if desired; run the 60-second test with the screen locked. Test **Checked**, **Undo**, **Snooze**, and **Stop Sound**.
4. Restart the phone and verify reminders remain scheduled. Check auto-start/optimizations on OEM devices. Test after a package update and timezone change too.
5. Export a JSON backup occasionally.

## Storage guidelines

An unused lithium rechargeable battery generally ages more slowly when stored partially charged (often around 40–60%), powered off, and kept cool. Check sleeping handhelds more frequently; shut down units that drain within days. AA alkaline cells should be removed before long storage. When a battery swells or overheats, stop using/charging the device and follow appropriate battery handling guidance.

Intervals are **user-editable suggestions**, not medical/safety certifications: sleeping Android 3 days; Windows sleeping 1 day; power-off handheld 30 days; retro handheld 45 days; rechargeable controller 90 days. Thor is initially set to a 1-day check because of reported rapid drain; this does not assume it is actually sleeping. If two valid manual percentages show rapid drain, the app can suggest a shorter interval, never silently lengthen it.

## Sources and design review

- PinTask implementation reviewed: `https://github.com/dzepdzep/PinTask` (version 3.18) — exact/inexact alarms, notification actions, audio service, persistence and recovery are the inspiration. No PinTask account, data or code module is shared by this app.
- Android exact alarm permissions and fallbacks: `https://developer.android.com/about/versions/14/changes/schedule-exact-alarms`
- Android alarm timing: `https://developer.android.com/develop/background-work/services/alarms`
- Foreground service restrictions: `https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start`
- Android 15 boot/media-playback restriction: `https://developer.android.com/about/versions/15/behavior-changes-15`

## Known limitations / follow-up QA

- The initial UI is English-only; localization is a follow-up. No photo library or automatic Bluetooth telemetry yet.
- Bulk editing, cloud sync, full PinTask-style free-form tasks and shift scheduling were intentionally **not** imported because this app is specifically for device maintenance.
- Android platform builds and real-device notification/audio/lock-screen testing are still pending. The first release should be treated as a prototype until those checks pass.
