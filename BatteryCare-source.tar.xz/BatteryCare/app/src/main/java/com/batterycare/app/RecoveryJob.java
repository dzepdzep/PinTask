package com.batterycare.app;

import android.app.job.*;
import android.content.*;

/** Best-effort watchdog, not a guarantee or substitute for the scheduled alarm. */
public final class RecoveryJob extends JobService {
    static final int ID=0x42415443;
    static void ensure(Context c){
        JobScheduler s=c.getSystemService(JobScheduler.class);if(s==null||s.getPendingJob(ID)!=null)return;
        JobInfo job=new JobInfo.Builder(ID,new ComponentName(c,RecoveryJob.class))
            .setPeriodic(15*60*1000L).setPersisted(true).build();
        s.schedule(job);
    }
    @Override public boolean onStartJob(JobParameters params){
        new Thread(()->{
            try {Reminders.deliverDue(getApplicationContext(),"watchdog");
                 Reminders.rescheduleAll(getApplicationContext());Reminders.sync(getApplicationContext());}
            catch(RuntimeException error){android.util.Log.w("BatteryCare","Recovery failed",error);}
            finally{jobFinished(params,false);}
        },"batterycare-recovery").start();return true;
    }
    @Override public boolean onStopJob(JobParameters p){return true;}
}
