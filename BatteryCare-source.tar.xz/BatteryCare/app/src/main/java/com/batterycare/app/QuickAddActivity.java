package com.batterycare.app;

import android.app.*;
import android.os.Bundle;
import android.text.InputType;
import android.view.*;
import android.widget.*;

/** Compact typed Quick Add from the widget, without opening the entire application. */
public final class QuickAddActivity extends Activity {
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);
        int pad=(int)(18*getResources().getDisplayMetrics().density);
        form.setPadding(pad,pad,pad,pad);
        TextView label=new TextView(this);label.setText("Device or controller name");form.addView(label);
        EditText input=new EditText(this);input.setSingleLine(true);input.setHint("e.g. Switch Pro Controller");
        input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);form.addView(input);
        TextView typeLabel=new TextView(this);typeLabel.setText("Type");form.addView(typeLabel);
        Spinner type=new Spinner(this);
        String[] opts={"Android handheld","Windows handheld","Retro handheld","Controller","Other"};
        type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,opts));form.addView(type);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Battery Care · Quick Add").setView(form)
          .setNegativeButton("Cancel",(d,w)->finish()).setPositiveButton("Add",null)
          .setOnCancelListener(d->finish()).create();
        dlg.setOnShowListener(v->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view->{
            String name=input.getText().toString().trim();if(name.isEmpty()){input.setError("Enter device name");return;}
            DeviceStore.Device d=DeviceStore.newDevice();d.name=name;d.category=""+type.getSelectedItem();
            d.mode="Windows handheld".equals(d.category)?"Hibernate":"Powered off";
            d.days=BatteryMath.suggestedInterval(d.category,d.kind,d.mode);
            try(DeviceStore db=new DeviceStore(this)){d.id=db.save(d);Reminders.schedule(this,db.get(d.id));}
            BatteryWidget.updateAll(this);
            Toast.makeText(this,"Added · "+name,Toast.LENGTH_SHORT).show();
            dlg.dismiss();finish();
        }));
        dlg.show();
    }
}
